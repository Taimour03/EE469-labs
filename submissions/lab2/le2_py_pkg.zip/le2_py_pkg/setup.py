import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'le2_py_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.xml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='vboxuser',
    maintainer_email='taimour.abbasi01@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'sensor_driver_node = le2_py_pkg.sensor_driver_node:main',
            'sensor_processor_node = le2_py_pkg.sensor_processor_node:main',
            'le2_lifecycle_manager = le2_py_pkg.le2_lifecycle_manager:main',
        ],
    },
)
